<#  M365 Analytics Log Collector #>
#Requires -RunAsAdministrator
#----------------------------------------------------------------------------------------------------------
#
#                                          Parameter Declarations
#
#----------------------------------------------------------------------------------------------------------

Param(
# File share to store logs, the maximum length is 130 since the script would create sub folders and files 
[Parameter(Position=1)]
[string]$LogPath,

# LogMode == 0 log to console only
# LogMode == 1 log to file and console
# LogMode == 2 log to file only
[Parameter(Position=2)]
[Int16]$LogMode = 1,

# CollectNetTrace == 0 to disable collect Net Trace, otherwise enable collect Net Trace.
[Parameter(Position=3)]
[Int16]$CollectNetTrace = 0,

# CollectUTCTrace == 0 to disable collect UTC Trace, otherwise enable collect UTC Trace.
[Parameter(Position=4)]
[Int16]$CollectUTCTrace = 0,

# -AcceptEULA = silently accept EULA
[switch]$AcceptEula
)

#----------------------------------------------------------------------------------------------------------
#
#                                          Startup
#
#----------------------------------------------------------------------------------------------------------

# Make sure we are running x64 PS on 64-bit OS. If not then start a x64 process of PowerShell
$powerShellHome = $PSHOME.ToLower()
if ([System.Environment]::Is64BitOperatingSystem -eq $true)
{
    if ([System.Environment]::Is64BitProcess -eq $false)
    {
        Write-Verbose "Launching x64 PowerShell"
        $powerShellHome = $powerShellHome.Replace('syswow64','sysnative')
        &"$powerShellHome\powershell.exe" -ExecutionPolicy AllSigned -NonInteractive -NoProfile $myInvocation.Line
        exit $lastexistcode
    }
}

#----------------------------------------------------------------------------------------------------------
#
#                                          Check DiagTools EULA
#
#----------------------------------------------------------------------------------------------------------
[void][System.Reflection.Assembly]::Load('System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
[void][System.Reflection.Assembly]::Load('System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')

function ShowEULAPopup($mode)
{
    $EULA = New-Object -TypeName System.Windows.Forms.Form
    $richTextBox1 = New-Object System.Windows.Forms.RichTextBox
    $btnAcknowledge = New-Object System.Windows.Forms.Button
    $btnCancel = New-Object System.Windows.Forms.Button

    $EULA.SuspendLayout()
    $EULA.Name = "EULA"
    $EULA.Text = "Microsoft Diagnostic Tools End User License Agreement"

    $richTextBox1.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $richTextBox1.Location = New-Object System.Drawing.Point(12,12)
    $richTextBox1.Name = "richTextBox1"
    $richTextBox1.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Vertical
    $richTextBox1.Size = New-Object System.Drawing.Size(776, 397)
    $richTextBox1.TabIndex = 0
    $richTextBox1.ReadOnly=$True
    $richTextBox1.Add_LinkClicked({Start-Process -FilePath $_.LinkText})
    $richTextBox1.Rtf = @"
{\rtf1\ansi\ansicpg1252\deff0\nouicompat{\fonttbl{\f0\fswiss\fprq2\fcharset0 Segoe UI;}{\f1\fnil\fcharset0 Calibri;}{\f2\fnil\fcharset0 Microsoft Sans Serif;}}
{\colortbl ;\red0\green0\blue255;}
{\*\generator Riched20 10.0.19041}{\*\mmathPr\mdispDef1\mwrapIndent1440 }\viewkind4\uc1 
\pard\widctlpar\f0\fs19\lang1033 MICROSOFT SOFTWARE LICENSE TERMS\par
Microsoft Diagnostic Scripts and Utilities\par
\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}These license terms are an agreement between you and Microsoft Corporation (or one of its affiliates). IF YOU COMPLY WITH THESE LICENSE TERMS, YOU HAVE THE RIGHTS BELOW. BY USING THE SOFTWARE, YOU ACCEPT THESE TERMS.\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}\par
\pard 
{\pntext\f0 1.\tab}{\*\pn\pnlvlbody\pnf0\pnindent0\pnstart1\pndec{\pntxta.}}
\fi-360\li360 INSTALLATION AND USE RIGHTS. Subject to the terms and restrictions set forth in this license, Microsoft Corporation (\ldblquote Microsoft\rdblquote ) grants you (\ldblquote Customer\rdblquote  or \ldblquote you\rdblquote ) a non-exclusive, non-assignable, fully paid-up license to use and reproduce the script or utility provided under this license (the "Software"), solely for Customer\rquote s internal business purposes, to help Microsoft troubleshoot issues with one or more Microsoft products, provided that such license to the Software does not include any rights to other Microsoft technologies (such as products or services). \ldblquote Use\rdblquote  means to copy, install, execute, access, display, run or otherwise interact with the Software. \par
\pard\widctlpar\par
\pard\widctlpar\li360 You may not sublicense the Software or any use of it through distribution, network access, or otherwise. Microsoft reserves all other rights not expressly granted herein, whether by implication, estoppel or otherwise. You may not reverse engineer, decompile or disassemble the Software, or otherwise attempt to derive the source code for the Software, except and to the extent required by third party licensing terms governing use of certain open source components that may be included in the Software, or remove, minimize, block, or modify any notices of Microsoft or its suppliers in the Software. Neither you nor your representatives may use the Software provided hereunder: (i) in a way prohibited by law, regulation, governmental order or decree; (ii) to violate the rights of others; (iii) to try to gain unauthorized access to or disrupt any service, device, data, account or network; (iv) to distribute spam or malware; (v) in a way that could harm Microsoft\rquote s IT systems or impair anyone else\rquote s use of them; (vi) in any application or situation where use of the Software could lead to the death or serious bodily injury of any person, or to physical or environmental damage; or (vii) to assist, encourage or enable anyone to do any of the above.\par
\par
\pard\widctlpar\fi-360\li360 2.\tab DATA. Customer owns all rights to data that it may elect to share with Microsoft through using the Software. You can learn more about data collection and use in the help documentation and the privacy statement at {{\field{\*\fldinst{HYPERLINK https://aka.ms/privacy }}{\fldrslt{https://aka.ms/privacy\ul0\cf0}}}}\f0\fs19 . Your use of the Software operates as your consent to these practices.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 3.\tab FEEDBACK. If you give feedback about the Software to Microsoft, you grant to Microsoft, without charge, the right to use, share and commercialize your feedback in any way and for any purpose.\~ You will not provide any feedback that is subject to a license that would require Microsoft to license its software or documentation to third parties due to Microsoft including your feedback in such software or documentation. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 4.\tab EXPORT RESTRICTIONS. Customer must comply with all domestic and international export laws and regulations that apply to the Software, which include restrictions on destinations, end users, and end use. For further information on export restrictions, visit {{\field{\*\fldinst{HYPERLINK https://aka.ms/exporting }}{\fldrslt{https://aka.ms/exporting\ul0\cf0}}}}\f0\fs19 .\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 5.\tab REPRESENTATIONS AND WARRANTIES. Customer will comply with all applicable laws under this agreement, including in the delivery and use of all data. Customer or a designee agreeing to these terms on behalf of an entity represents and warrants that it (i) has the full power and authority to enter into and perform its obligations under this agreement, (ii) has full power and authority to bind its affiliates or organization to the terms of this agreement, and (iii) will secure the permission of the other party prior to providing any source code in a manner that would subject the other party\rquote s intellectual property to any other license terms or require the other party to distribute source code to any of its technologies.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 6.\tab DISCLAIMER OF WARRANTY. THE SOFTWARE IS PROVIDED \ldblquote AS IS,\rdblquote  WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\par
\pard\widctlpar\qj\par
\pard\widctlpar\fi-360\li360\qj 7.\tab LIMITATION ON AND EXCLUSION OF DAMAGES. IF YOU HAVE ANY BASIS FOR RECOVERING DAMAGES DESPITE THE PRECEDING DISCLAIMER OF WARRANTY, YOU CAN RECOVER FROM MICROSOFT AND ITS SUPPLIERS ONLY DIRECT DAMAGES UP TO U.S. $5.00. YOU CANNOT RECOVER ANY OTHER DAMAGES, INCLUDING CONSEQUENTIAL, LOST PROFITS, SPECIAL, INDIRECT, OR INCIDENTAL DAMAGES. This limitation applies to (i) anything related to the Software, services, content (including code) on third party Internet sites, or third party applications; and (ii) claims for breach of contract, warranty, guarantee, or condition; strict liability, negligence, or other tort; or any other claim; in each case to the extent permitted by applicable law. It also applies even if Microsoft knew or should have known about the possibility of the damages. The above limitation or exclusion may not apply to you because your state, province, or country may not allow the exclusion or limitation of incidental, consequential, or other damages.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 8.\tab BINDING ARBITRATION AND CLASS ACTION WAIVER. This section applies if you live in (or, if a business, your principal place of business is in) the United States.  If you and Microsoft have a dispute, you and Microsoft agree to try for 60 days to resolve it informally. If you and Microsoft can\rquote t, you and Microsoft agree to binding individual arbitration before the American Arbitration Association under the Federal Arbitration Act (\ldblquote FAA\rdblquote ), and not to sue in court in front of a judge or jury. Instead, a neutral arbitrator will decide. Class action lawsuits, class-wide arbitrations, private attorney-general actions, and any other proceeding where someone acts in a representative capacity are not allowed; nor is combining individual proceedings without the consent of all parties. The complete Arbitration Agreement contains more terms and is at {{\field{\*\fldinst{HYPERLINK https://aka.ms/arb-agreement-4 }}{\fldrslt{https://aka.ms/arb-agreement-4\ul0\cf0}}}}\f0\fs19 . You and Microsoft agree to these terms. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 9.\tab LAW AND VENUE. If U.S. federal jurisdiction exists, you and Microsoft consent to exclusive jurisdiction and venue in the federal court in King County, Washington for all disputes heard in court (excluding arbitration). If not, you and Microsoft consent to exclusive jurisdiction and venue in the Superior Court of King County, Washington for all disputes heard in court (excluding arbitration).\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 10.\tab ENTIRE AGREEMENT. This agreement, and any other terms Microsoft may provide for supplements, updates, or third-party applications, is the entire agreement for the software.\par
\pard\sa200\sl276\slmult1\f1\fs22\lang9\par
\pard\f2\fs17\lang2057\par
}
"@
    $richTextBox1.BackColor = [System.Drawing.Color]::White
    $btnAcknowledge.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnAcknowledge.Location = New-Object System.Drawing.Point(544, 415)
    $btnAcknowledge.Name = "btnAcknowledge";
    $btnAcknowledge.Size = New-Object System.Drawing.Size(119, 23)
    $btnAcknowledge.TabIndex = 1
    $btnAcknowledge.Text = "Accept"
    $btnAcknowledge.UseVisualStyleBackColor = $True
    $btnAcknowledge.Add_Click({$EULA.DialogResult=[System.Windows.Forms.DialogResult]::Yes})

    $btnCancel.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnCancel.Location = New-Object System.Drawing.Point(669, 415)
    $btnCancel.Name = "btnCancel"
    $btnCancel.Size = New-Object System.Drawing.Size(119, 23)
    $btnCancel.TabIndex = 2
    if($mode -ne 0)
    {
	    $btnCancel.Text = "Close"
    }
    else
    {
	    $btnCancel.Text = "Decline"
    }
    $btnCancel.UseVisualStyleBackColor = $True
    $btnCancel.Add_Click({$EULA.DialogResult=[System.Windows.Forms.DialogResult]::No})

    $EULA.AutoScaleDimensions = New-Object System.Drawing.SizeF(6.0, 13.0)
    $EULA.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Font
    $EULA.ClientSize = New-Object System.Drawing.Size(800, 450)
    $EULA.Controls.Add($btnCancel)
    $EULA.Controls.Add($richTextBox1)
    if($mode -ne 0)
    {
	    $EULA.AcceptButton=$btnCancel
    }
    else
    {
        $EULA.Controls.Add($btnAcknowledge)
	    $EULA.AcceptButton=$btnAcknowledge
        $EULA.CancelButton=$btnCancel
    }
    $EULA.ResumeLayout($false)
    $EULA.Size = New-Object System.Drawing.Size(800, 650)

    Return ($EULA.ShowDialog())
}

function ShowEULAIfNeeded($toolName, $mode)
{
	$eulaRegPath = "HKCU:Software\Microsoft\CESDiagnosticTools"
	$eulaAccepted = "No"
	$eulaValue = $toolName + " EULA Accepted"
	if(Test-Path $eulaRegPath)
	{
		$eulaRegKey = Get-Item $eulaRegPath
		$eulaAccepted = $eulaRegKey.GetValue($eulaValue, "No")
	}
	else
	{
		$eulaRegKey = New-Item $eulaRegPath
	}
	if($mode -eq 2) # silent accept
	{
		$eulaAccepted = "Yes"
       		$ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
	}
	else
	{
		if($eulaAccepted -eq "No")
		{
			$eulaAccepted = ShowEULAPopup($mode)
			if($eulaAccepted -eq [System.Windows.Forms.DialogResult]::Yes)
			{
	        		$eulaAccepted = "Yes"
	        		$ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
			}
		}
	}
	return $eulaAccepted
}

if ($AcceptEula) {
    $eulaAccepted = ShowEULAIfNeeded "M365 Analytics Log Collector" 2
} else {
    $eulaAccepted = ShowEULAIfNeeded "M365 Analytics Log Collector" 0
    if($eulaAccepted -ne "Yes") {
        exit
    }
}


#----------------------------------------------------------------------------------------------------------
#
#                                          Parameter Intialization and Validation 
#
#----------------------------------------------------------------------------------------------------------

# Parameter: $LogPath
if([String]::IsNullOrEmpty($LogPath) -or [String]::IsNullOrWhiteSpace($LogPath))
{
    # Set to default value
    $LogPath = "$Env:SystemDrive\M365AnalyticsLogs"
}
else
{
    Write-Verbose "Validating path length no more than 130: $LogPath"
    $LogPath = $LogPath.Trim().TrimEnd('\')
    if($LogPath.Length -gt 130)
    {
        throw "Failed to validate the length of the given path: $LogPath"
    }

    # Validate parameter: $LogPath
    Write-Verbose "Validating path format: $LogPath"
    $validateResult = $false
    
    if((Test-Path $LogPath -IsValid) -eq $true)
    {
        $testSplitArray = $LogPath.Split(':')

        if($testSplitArray.Count -eq 1)
        {
            $validateResult = $true
        }
        elseif($testSplitArray.Count -eq 2)
        {
            $targetDrv = Get-PSDrive -Name $testSplitArray[0]   

            if($targetDrv -ne $null)
            {
                $fileDrv = Get-PSProvider -PSProvider FileSystem

                if($fileDrv -ne $null)
                {
                    if($fileDrv.Drives.Contains($targetDrv) -eq $true)
                    {
                         $validateResult = $true
                    }
                }
            }
        }
    }

    if($validateResult -eq $false)
    {
        throw "Failed to validate the format of the given path: $LogPath"
    }
}

Write-Verbose "Output Path = $LogPath"

# Parameter: $LogMode
Write-Verbose "Validating log mode(0|1|2): $LogMode"

if(($LogMode -ne 0) -and ($LogMode -ne 1) -and ($LogMode -ne 2))
{
    throw "Failed to validate the given log mode: $LogMode"
}

Write-Verbose "Log Mode = $LogMode"

# Parameter: $CollectNetTrace
if($CollectNetTrace -eq 0)
{
    Write-Verbose "Collect Net Trace = No"
}
else
{
    Write-Verbose "Collect Net Trace = Yes"
}

# Parameter: $CollectUTCTrace
if($CollectUTCTrace -eq 0)
{
    Write-Verbose "Collect UTC Trace = No"
}
else
{
    Write-Verbose "Collect UTC Trace = Yes"
}


#----------------------------------------------------------------------------------------------------------
#
#                                          Global Variables
#
#----------------------------------------------------------------------------------------------------------

# Temporary file to store providers
$global:tempProviderFile = [System.IO.Path]::GetTempFileName()

# Providers info
$global:providersText = @"
{43ac453b-97cd-4b51-4376-db7c9bb963ac}	0	255
{56DC463B-97E8-4B59-E836-AB7C9BB96301}	0	255
"@

# Script folder root
$global:scriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path

# Set the exit code to the first exception exit code
$global:errorCode = [string]::Empty;

# Total error count while running the script
[int]$global:errorCount = 0;

# OS version
$global:osVersion = (Get-WmiObject Win32_OperatingSystem).Version

# OS name
$global:operatingSystemName = (Get-WmiObject Win32_OperatingSystem).Name

# OS Architecture
$global:osArchitecture = $ENV:Processor_Architecture

# Global utc trace name
$global:timeStart=Get-Date
$global:timeStartString=$global:timeStart.ToString("yy_MM_dd_HH_mm_ss")
$global:utcTraceName = "utctrace" + $global:timeStartString

#----------------------------------------------------------------------------------------------------------------
#
#                                                   Main
#
#----------------------------------------------------------------------------------------------------------------

$main = {
    Try
    {    
        # Initialize provider file
        InitializeProviderFile

        # Quit if System variable WINDIR is not set
        Try
        {
            $global:windir=[System.Environment]::ExpandEnvironmentVariables("%WINDIR%")
        }
        Catch
        {
            $exceptionDetails = "Exception: " + $_.Exception.Message + "HResult: " + $_.Exception.HResult
            Write-Error "Failure finding system variable WINDIR. $exceptionDetails Error 23"
            [System.Environment]::Exit(23)
        }

        # Create the log file if logMode requires logging to file.
        CreateLogFile
                
        # Get Sqm Machine Id
        Get-SqmID
        
        # Get ConfigMgr Client Version
        Get-CmClientVersion

        Log "Starting M365AnalyticsLogsCollector"
        Log "UTC DateTime: $global:utcDate"
        Log "OS: $global:osVersion"
        Log "Architecture: $global:osArchitecture"
        Log "Machine Sqm Id: $global:sClientId"
        Log "Configuration Manager Client Version: $global:smsClientVersion"

        # Sets VerboseMode to enable appraiser logging value to the registry
        SetAppraiserVerboseMode

        # Sets RequestAllAppraiserVersions key
        if($global:osBuildNumber -lt 10240)
        {
            SetRequestAllAppraiserVersions
        }

        if($CollectNetTrace -ne 0)
        {
            # Start Netsh trace
            StartNetworkTrace
        }

        if($CollectUTCTrace -ne 0)
        {
            #Start UTC trace
            StartUTCTrace
        }

        # restart Diagtrack service
        RestartDiagtrack

        # Run Connectivity Tool
        RunConnectivityDiagnosis

        # Run Census
        RunCensus

        if($CollectNetTrace -ne 0)
        {
            # Stop Netsh trace
            StopNetworkTrace
        }        

        if($CollectUTCTrace -ne 0)
        {
            # Stop UTC trace
            StopUTCTrace
        }        

        # Run Appraiser
        RunAppraiser

        # Collect the logs
        Try
        {
            Log "Running diagnose_internal to collect logs"
            DiagnoseInternal $global:logFolder
        }
        Catch
        {
            Log "diagnose_internal failed with unexpected exception" "Error" "37" "diagnose_internal" $_.Exception.HResult $_.Exception.Message
        }

        # Collect M365AHandler logs
        CollectM365AHandlerLog

        if($global:errorCount -eq 0)
        {
            Log "Script finished successfully"
            Exit(0)
        }
    }
    Catch
    {
        Log "Unexpected error occured while executing the script" "Error" "1" "UnExpectedException" $_.Exception.HResult $_.Exception.Message
        Log "Script failed" "Failure" "1" "ScriptEnd"
        [System.Environment]::Exit(1)
    }
    Finally
    {
        # Disable appriaser verbose mode after running the appriaser
        DisableAppraiserVerboseMode

        # Restart Diagtrack service
        RestartDiagtrack

        # Cleanup temporary file
        Remove-Item -Path $global:tempProviderFile
    }
}

#----------------------------------------------------------------------------------------------------------
#
#                                          Function Definitions
#
#----------------------------------------------------------------------------------------------------------

function InitializeProviderFile
{
    $global:providersText | Out-File $global:tempProviderFile -Append -Encoding ascii
}

function DiagnoseInternal($diaLogPath)
{
    if ((test-path $diaLogPath) -eq $false)
    {
        New-Item -ItemType Directory -Path $diaLogPath -Force | Out-Null
    }

    Get-WmiObject -Query 'select * from win32_quickfixengineering' | sort hotfixid | Out-File "$diaLogPath\installedKBs.txt" -Force

    ROBOCOPY "$env:windir\appcompat" "$diaLogPath\appcompat" *.* /E /XF *.hve* /R:1  | Out-Null

    regedit /e "$diaLogPath\RegAppCompatFlags.txt" "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags"
    regedit /e "$diaLogPath\RegCensus.txt" "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Census"
    regedit /e "$diaLogPath\RegSQM.txt" "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\SQMClient"
    regedit /e "$diaLogPath\RegDiagTrack.txt" "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack"
    regedit /e "$diaLogPath\RegPoliciesDataCollection.txt" "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection"
    regedit /e "$diaLogPath\RegDataCollection.txt" "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
}

function Get-SqmID
{
    Try
    {
        $sqmID = (Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\SQMClient -Name MachineId).MachineId
        $global:sClientId = "s:" + $sqmID.Substring(1).Replace("}", "")
    }
    Catch
    {
        $hexHresult = "{0:X}" -f $_.Exception.HResult
        $exceptionMessage = $_.Exception.Message
        Write-Error "Get-SqmID failed with unexpected exception.`nException: $exceptionMessage HResult:  0x$hexHresult"
        [System.Environment]::Exit(38)
    }
}

function Get-CmClientVersion
{
    try {
        $propertyPath = "HKLM:\SOFTWARE\Microsoft\SMS\Mobile Client"
        $propertyName = "SmsClientVersion"
        if (Test-Path -Path $propertyPath)
        {
            $property = Get-ItemProperty -Path $propertyPath -Name $propertyName -ErrorAction SilentlyContinue
            if ($null -eq $property)
            {
                Log "Get-CmClientVersion: Could not find registry value $propertyName at path $propertyPath" "Warning"
            }
            else {
                $global:smsClientVersion = $property.SmsClientVersion
            }
        }
        else 
        {
            Log "Get-CmClientVersion: Could not find registry key $propertyPath" "Warning"
        }
    }
    catch {
        Log "Get-CmClientVersion: Error getting $propertyName registry value at path $propertyPath" "Warning" $null "Get-CmClientVersion" $_.Exception.HResult $_.Exception.Message
    }    
}

function CreateLogFile
{
    Write-Verbose "Creating output folder"
    $timeStart=Get-Date
    $timeStartString=$timeStart.ToString("yy_MM_dd_HH_mm_ss")
    $logFolderName = "M365AnalyticsLogs_" + $timeStartString
    $global:logFolder = $logPath +"\"+$logFolderName

    Try
    {   
        $outputFolder = New-Item $global:logFolder -type directory
        Write-Host "Output folder created successfully: $outputFolder"
    }
    Catch
    {
        $hexHresult = "{0:X}" -f $_.Exception.HResult
        $exceptionMessage = $_.Exception.Message
        Write-Error "Could not create output folder at the given logPath: $LogPath`nException: $exceptionMessage HResult:  0x$hexHresult"
        [System.Environment]::Exit(28)
    }

    if($LogMode -ne 0)
    {
        Write-Verbose "Creating Log File"
        $fileName = $logFolderName+".txt"
        $global:logFile=$global:logFolder+"\"+$fileName

        Try
        {
            New-Item $global:logFile -type file | Out-Null
            Write-Verbose "Log File created successfully: $global:logFile"
        }
        Catch
        {
            $hexHresult = "{0:X}" -f $_.Exception.HResult
            $exceptionMessage = $_.Exception.Message
            Write-Error "Could not create log file at the given logPath: $LogPath`nException: $exceptionMessage HResult:  0x$hexHresult"
            [System.Environment]::Exit(28)
        }
    }
}

function StartNetworkTrace
{
    Try
    {
        Log "Start: StartNetworkTrace"
        netsh trace start capture=yes scenario=InternetClient provider=Microsoft-Windows-CAPI2 traceFile="$global:logFolder\nettrace.etl" | Out-Null
        Log "Passed: StartNetworkTrace"
    }
    Catch
    {
        Log "StartNetworkTrace failed with an unexpected exception." "Error" "2001" "StartNetworkTrace" $_.Exception.HResult $_.Exception.Message
    }
}

function StartUTCTrace
{
    Try
    {
        Log "Start: StartUTCTrace"
        
        $logmanFolder = $null
        if($global:osArchitecture.contains("64"))
        {
            $logmanFolder = "$global:windir\system32\"
        }
        else
        {
            $logmanFolder = "$global:windir\system32\"
        }

        & logman start $global:utcTraceName -pf "$global:tempProviderFile" -bs 32768 -nb 128 -ets -o "$global:logFolder\DAUTCtrace.etl" | Out-Null
                
        Log "Passed: StartUTCTrace"
    }
    Catch
    {
        Log "StartUTCTrace failed with an unexpected exception." "Error" "2003" "StartUTCTrace" $_.Exception.HResult $_.Exception.Message
    }   
}

function StopNetworkTrace
{
    Try
    {
        Log "Start: StopNetworkTrace"
        netsh trace stop | Out-Null
        Log "Passed: StopNetworkTrace"
    }
    Catch
    {
        Log "StopNetworkTrace failed with an unexpected exception." "Error" "2002" "StopNetworkTrace" $_.Exception.HResult $_.Exception.Message
    }
}

function StopUTCTrace
{
    Try
    {
        Log "Start: StopUTCTrace"

        $logmanFolder = $null
        if($global:osArchitecture.contains("64"))
        {
            $logmanFolder = "$global:windir\system32\"
        }
        else
        {
            $logmanFolder = "$global:windir\system32\"
        }

        & logman.exe stop $global:utcTraceName -ets | Out-Null

        Log "Passed: StopUTCTrace"
        Log "Collect DownloadedSettings to log folder"
        & takeown -f "$Env:ProgramData\Microsoft\Diagnosis\DownloadedSettings\*" | Out-Null
        & icacls "$Env:ProgramData\Microsoft\Diagnosis\DownloadedSettings\*" /grant administrators:f | Out-Null
        New-Item $global:logFolder\DownloadedSettings -type directory | Out-Null
        Copy-Item "$Env:ProgramData\Microsoft\Diagnosis\DownloadedSettings\*" -Destination $global:logFolder\DownloadedSettings | Out-Null
    }
    Catch
    {
        Log "StopUTCTrace failed with an unexpected exception." "Error" "2004" "StopUTCTrace" $_.Exception.HResult $_.Exception.Message
    } 
    
}

function RestartDiagtrack
{
    Log "Start: RestartDiagtrack"
    Try
    {
        & Net stop diagtrack | Out-Null
        & Reg add hklm\software\microsoft\windows\currentversion\diagnostics\diagtrack\testhooks /v ResetEventStore /t REG_DWORD /d 1 /f | Out-Null 
        & Net start diagtrack | Out-Null 
        & Reg delete hklm\software\microsoft\windows\currentversion\diagnostics\diagtrack\testhooks /v ResetEventStore /f | Out-Null
        Log "Passed: RestartDiagtrack"
    }    
    Catch
    {
        Log "RestartDiagtrack failed to execute - script will continue." "Warning" $null "RestartDiagtrack" $_.Exception.HResult $_.Exception.Message
        return
    }
}

function RunConnectivityDiagnosis
{
    Log "Start: RunConnectivityDiagnosis"
    Try
    {
        $propertyPath = "HKLM:\SOFTWARE\Microsoft\CCM\Logging\@Global"
        if(Test-Path -Path $propertyPath)
        {
            if ((Get-ItemProperty -Path $propertyPath -Name LogDirectory -ErrorAction SilentlyContinue) -eq $null)
            {
	            Log "Could not find registry key LogDirectory at path HKLM:\SOFTWARE\Microsoft\CCM\Logging\@Global"
            }
            else
            {
                Try
                {
                    $logDirectoryKeyM365 = Get-ItemProperty -Path $propertyPath -Name LogDirectory
                    $logDirectoryM365 = $logDirectoryKeyM365.LogDirectory
                    $connectivitydiagnosis = $logDirectoryM365.ToString().Replace("Logs", "settingsplugins\connectivitydiagnosis.exe")
                    
                    if((Test-Path -Path $connectivitydiagnosis) -eq $False)
                    {
                       $connectivitydiagnosis = $logDirectoryM365.ToString().Replace("Logs", "connectivitydiagnosis.exe") 
                    }
                    
	            }
	            Catch {
		            Log "Error running RunConnectivityDiagnosis" "Warning" $null "RunConnectivityDiagnosis" $_.Exception.HResult $_.Exception.Message
                    return
	            }
            }
        }
        else {
            Log "RunConnectivityDiagnosis: HKLM:\SOFTWARE\Microsoft\CCM\Logging\@Global not found. Falling back to script root directory" "Warning"
            # fall back to see if executable exists in script root directory
            $connectivitydiagnosis = Join-Path $global:scriptRoot "connectivitydiagnosis.exe"
            if (-not (Test-Path -Path $connectivitydiagnosis)) {
                Log "Error running RunConnectivityDiagnosis" "Warning" $null "RunConnectivityDiagnosis" "Could not find ConnectivityDiagnosis.exe"
                return
            }
        }

        #Log $connectivitydiagnosis
        #Log $logDirectoryM365
        $currentDirectory = $global:scriptRoot
        & cd $global:logFolder
        & timeout 5 | Out-Null
        & $connectivitydiagnosis -verbose > ConnectivityDiagnosis.txt 
        & timeout 5 | Out-Null
        & cd $currentDirectory
        Log "Passed: RunConnectivityDiagnosis"

    }
    Catch
    {
	    Log "Error running RunConnectivityDiagnosis" "Warning" $null "RunConnectivityDiagnosis" $_.Exception.HResult $_.Exception.Message
    }
}

function SetAppraiserVerboseMode
{
    Log "Start: SetAppraiserVerboseMode"
    Try
    {
        $vAppraiserPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Appraiser"
        Log "Enabling Appraiser logs for debugging by setting VerboseMode property to 1 at the registry key path: $vAppraiserPath"
        if ((Get-ItemProperty -Path $vAppraiserPath -Name VerboseMode -ErrorAction SilentlyContinue) -eq $null)
        {
	    Try
            {
		New-ItemProperty -Path $vAppraiserPath -Name VerboseMode -PropertyType DWord -Value 1 | Out-Null
	    }
	    Catch
            {
		Log "SetAppraiserVerboseMode failed to write the VerboseMode property at registry key $vAppraiserPath. This is not fatal, script will continue." "Warning" $null "SetAppraiserVerboseMode" $_.Exception.HResult $_.Exception.Message
                return
	    }
        }
        else
        {
	    Log "Appraiser verbose mode is already enabled"
        }

        Log "Enabling Appraiser logs for debugging by setting TestHooksEnabled property to 1 at the registry key path: $vAppraiserPath"
        if ((Get-ItemProperty -Path $vAppraiserPath -Name TestHooksEnabled -ErrorAction SilentlyContinue) -eq $null)
        {
	    Try
            {
		New-ItemProperty -Path $vAppraiserPath -Name TestHooksEnabled -PropertyType DWord -Value 1 | Out-Null
	    }
	    Catch
            {
		Log "SetAppraiserVerboseMode failed to write the TestHooksEnabled property at registry key $vAppraiserPath. This is not fatal, script will continue." "Warning" $null "SetAppraiserVerboseMode" $_.Exception.HResult $_.Exception.Message
                return
	    }
        }
        else
        {
	    Log "Appraiser TestHooksEnabled property is already set"
        }

        Log "Passed: SetAppraiserVerboseMode"
    }
    Catch
    {
	Log "SetAppraiserVerboseMode failed with unexpected exception. This is not fatal, script will continue." "Warning" $null "SetAppraiserVerboseMode" $_.Exception.HResult $_.Exception.Message
    }
}

function DisableAppraiserVerboseMode
{
    Log "Start: DisableAppraiserVerboseMode"
    Try
    {
        $vAppraiserPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Appraiser"
        if ((Get-ItemProperty -Path $vAppraiserPath -Name VerboseMode -ErrorAction SilentlyContinue) -ne $null)
        {
	    Try
            {
		Remove-ItemProperty -Path $vAppraiserPath -Name VerboseMode
	    }
	    Catch
            {
		Log "DisableAppraiserVerboseMode failed deleting VerboseMode property at registry key path: $vAppraiserPath. This is not fatal, script will continue." "Warning" $null "DisableAppraiserVerboseMode" $_.Exception.HResult $_.Exception.Message
	    }
        }
        else
        {
	    Log "Appraiser VerboseMode key already deleted"
        }

        Log "Passed: DisableAppraiserVerboseMode"
    }
    Catch
    {
	Log "DisableAppraiserVerboseMode failed with unexpected exception. This is not fatal, script will continue." "Warning" $null "DisableAppraiserVerboseMode" $_.Exception.HResult $_.Exception.Message
    }
}

function SetRequestAllAppraiserVersions
{
    Log "Start: SetRequestAllAppraiserVersions"
    Try
    {
        $propertyPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection"
        $propertyGPOPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
        if(Test-Path -Path $propertyPath)
        {
            if ((Get-ItemProperty -Path $propertyPath -Name RequestAllAppraiserVersions -ErrorAction SilentlyContinue) -eq $null)
            {
	        Try
                {
		    New-ItemProperty -Path $propertyPath -Name RequestAllAppraiserVersions -PropertyType DWord -Value 1 | Out-Null
	        }
	        Catch
                {
		    Log "SetRequestAllAppraiserVersions failed setting RequestAllAppraiserVersions property at registry key path: $propertyPath" "Error" "20" "SetRequestAllAppraiserVersions" $_.Exception.HResult $_.Exception.Message
                    return
                }
            }
            else
            {
                Try
                {
		    Set-ItemProperty -Path $propertyPath -Name RequestAllAppraiserVersions -Value 1
	        }
	        Catch
                {
		    Log "SetRequestAllAppraiserVersions failed setting RequestAllAppraiserVersions property at registry key path: $propertyPath" "Error" "20" "SetRequestAllAppraiserVersions" $_.Exception.HResult $_.Exception.Message
                    return
	        }
            }
        }

        if(Test-Path -Path $propertyGPOPath)
        {
            if ((Get-ItemProperty -Path $propertyGPOPath -Name RequestAllAppraiserVersions -ErrorAction SilentlyContinue) -eq $null)
            {
	        Try
                {
		    New-ItemProperty -Path $propertyGPOPath -Name RequestAllAppraiserVersions -PropertyType DWord -Value 1 | Out-Null
	        }
	        Catch
                {
		    Log "SetRequestAllAppraiserVersions failed setting RequestAllAppraiserVersions property at registry key path: $propertyGPOPath" "Error" "20" "SetRequestAllAppraiserVersions" $_.Exception.HResult $_.Exception.Message
                    return
	        }
            }
            else
            {
                Try
                {
		    Set-ItemProperty -Path $propertyPath -Name RequestAllAppraiserVersions -Value 1
	        }
	        Catch
                {
		    Log "SetRequestAllAppraiserVersions failed setting RequestAllAppraiserVersions property at registry key path: $propertyGPOPath" "Error" "20" "SetRequestAllAppraiserVersions" $_.Exception.HResult $_.Exception.Message
                    return
	        }
            }
        }

        Log "Passed: SetRequestAllAppraiserVersions"
    }
    Catch
    {
	Log "SetRequestAllAppraiserVersions failed with unexpected exception." "Error" "21" "SetRequestAllAppraiserVersions" $_.Exception.HResult $_.Exception.Message
    }
}

function RunAppraiser
{
    Try
    {
	Log "Start: RunAppraiser"
        Log "Attempting to run inventory...This may take a few minutes to complete, please do not cancel the script."

        do
        {
            CompatTelRunner.exe -m:appraiser.dll -f:DoScheduledTelemetryRun ent | out-null
            $appraiserLastExitCode = $LASTEXITCODE
            $appraiserLastExitCodeHex = "{0:X}" -f $appraiserLastExitCode

            if($appraiserLastExitCode -eq 0x80070021)
            {
                Log "RunAppraiser needs to run CompatTelRunner.exe, but it is already running. Waiting for 60 seconds before retry."
                Start-Sleep -Seconds 60
            }
            else
            {
                break
            }

            $NoOfAppraiserRetries = $NoOfAppraiserRetries - 1

        }While($NoOfAppraiserRetries -gt 0)

	if ($appraiserLastExitCode -ne 0x0)
        {
            if ($appraiserLastExitCode -lt 0x0)
            {
		Log "RunAppraiser failed. CompatTelRunner.exe exited with last error code: 0x$appraiserLastExitCodeHex."  "Error" "33" "RunAppraiser" "0x$appraiserLastExitCodeHex" "CompatTelRunner.exe returned with an error code."
            }
            else
            {
                Log "RunAppraiser succeeded with a return code: 0x$appraiserLastExitCodeHex."
            }
	    }
        else
        {
            Log "Passed: RunAppraiser"
	}
    }
    Catch
    {
        Log "RunAppraiser failed with unexpected exception." "Error" "22" "RunAppraiser" $_.Exception.HResult $_.Exception.Message
    }
}

function RunCensus
{
    Log "Start: RunCensus"
    Try
    {
        $censusRunRegKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Census"

        if($(Test-Path $censusRunRegKey) -eq $false)
        {
	    New-Item -Path $censusRunRegKey -ItemType Key | Out-Null
        }

        # Turn Census FullSync mode on
        Log "Setting property: FullSync to value 1 at registry key path $censusRunRegKey to turn on Census FullSync mode"
        if ((Get-ItemProperty -Path $censusRunRegKey -Name FullSync -ErrorAction SilentlyContinue) -eq $null)
        {
	    New-ItemProperty -Path $censusRunRegKey -Name FullSync -PropertyType DWord -Value 1 | Out-Null
        }
        else
        {
            Set-ItemProperty -Path $censusRunRegKey -Name FullSync  -Value 1
        }


        # Run Census and validate the run
        # Census invocation commands are different for Windows 10 and Downlevel
        [int] $runCounterBefore = (Get-ItemProperty -Path $censusRunRegKey).RunCounter

        if($runCounterBefore -eq $null)
        {
            New-ItemProperty -Path $censusRunRegKey -Name RunCounter -PropertyType DWord -Value 0 | Out-Null
        }

        if($global:operatingSystemName.ToLower().Contains("windows 10"))
        {
            $censusExe = "$global:windir\system32\devicecensus.exe"
            if(Test-Path -Path $censusExe)
            {
                Log "Running $censusExe"
                & $censusExe | Out-Null
            }
            else
            {
                Log "$censusExe path not found" "Error" "52" "RunCensus"
                return
            }
        }
        else
        {
            CompatTelRunner.exe -m:generaltel.dll -f:DoCensusRun | Out-Null
        }

        [int] $runCounterAfter = (Get-ItemProperty -Path $censusRunRegKey).RunCounter
        $returnCode = (Get-ItemProperty -Path $censusRunRegKey).ReturnCode
        $startTime = Get-Date (Get-ItemProperty -Path $censusRunRegKey).StartTime
        $endTime = Get-Date (Get-ItemProperty -Path $censusRunRegKey).EndTime

        if($returnCode -eq 0)
        {
            if($runCounterAfter -gt $runCounterBefore -and $endTime -gt $startTime)
            {
                Log "Passed: RunCensus"
            }
            else
            {
                Log "Census did not run correctly. Registray data at $censusRunRegKey are: RunCounter Before trying to run Census:$runCounterBefore, RunCounter after trying to run Census:$runCounterAfter, ReturnCode:$returnCode, UTC StartTime:$startTime, UTC EndTime:$endTime" "Warning" $null "RunCensus"
            }
        }
        else
        {
            Log "Census returned a non zero ReturnCode:$returnCode" "Warning" $null "RunCensus"
        }

        # Turn Census FullSync mode off
        Log "Resetting property: FullSync to value 0 at registry key path $censusRunRegKey to turn off Census FullSync mode"
        Set-ItemProperty -Path $censusRunRegKey -Name FullSync  -Value 0

    }
    Catch
    {
        Log "RunCensus failed with unexpected exception" "Error" "51" "RunCensus" $_.Exception.HResult $_.Exception.Message
    }
}

function CollectM365AHandlerLog
{
    Log "Start: CollectM365AHandlerLog"
    Try
    {
        $propertyPath = "HKLM:\SOFTWARE\Microsoft\CCM\Logging\@Global"
        if(Test-Path -Path $propertyPath)
        {
            if ((Get-ItemProperty -Path $propertyPath -Name LogDirectory -ErrorAction SilentlyContinue) -eq $null)
            {
	        Log "Could not find registry key LogDirectory at path HKLM:\SOFTWARE\Microsoft\CCM\Logging\@Global"
            }
            else
            {
                Try
                {
		    $logDirectoryKeyM365 = Get-ItemProperty -Path $propertyPath -Name LogDirectory
                    $logDirectoryM365 = $logDirectoryKeyM365.LogDirectory
                    Copy-Item "$logDirectoryM365\M365AHandler.log" -Destination $global:logFolder | Out-Null
                    Log "Passed: CollectM365AHandlerLog"
	        }
	        Catch
                {
		    Log "Error getting logs at registry key LogDirectory at path HKLM:\SOFTWARE\Microsoft\CCM\Logging\@Global" "Warning" $null "CollectM365AHandlerLog" $_.Exception.HResult $_.Exception.Message
                    return
	        }
            }
        }
    }
    Catch
    {
	    Log "Error getting logs at registry key LogDirectory at path HKLM:\SOFTWARE\Microsoft\CCM\Logging\@Global" "Warning" $null "CollectM365AHandlerLog" $_.Exception.HResult $_.Exception.Message
    }

}

function Log($logMessage, $logLevel, $errorCode, $operation, $exceptionHresult, $exceptionMessage)
{
    $global:logDate = Get-Date -Format s
    $global:utcDate = ((Get-Date).ToUniversalTime()).ToString("yyyy-MM-ddTHH:mm:ssZ")
    $logMessageForAppInsights = $logMessage

    if(($logLevel -eq $null) -or ($logLevel -eq [string]::Empty))
    {
        $logLevel = "Info"
    }

    if($logLevel -eq "Error")
    {
        # check and update the errorCode (the script will exit with the first errorCode)
        if(($errorCode -ne $null) -and ($errorCode -ne [string]::Empty))
        {
            if(($global:errorCode -eq $null) -or ($global:errorCode -eq [string]::Empty))
            {
                $global:errorCode = $errorCode
            }

            $logMessage = "ErrorCode " + $errorCode + " : " + $logMessage
        }

        if($exceptionHresult -ne $null)
        {
             $logMessage = $logMessage + " HResult: " + $exceptionHresult
        }

        if($exceptionMessage -ne $null)
        {
            $logMessage = $logMessage + " ExceptionMessage: " + $exceptionMessage
        }

        $global:errorCount++
    }
    elseif($logLevel -eq "Exception")
    {
        if($exceptionHresult -ne $null)
        {
             $logMessage = $logMessage + " HResult: " + $exceptionHresult
        }

        if($exceptionMessage -ne $null)
        {
            $logMessage = $logMessage + " ExceptionMessage: " + $exceptionMessage
        }
    }
    elseif($logLevel -eq "Warning")
    {
        if($exceptionHresult -ne $null)
        {
             $logMessage = $logMessage + " HResult: " + $exceptionHresult
        }

        if($exceptionMessage -ne $null)
        {
            $logMessage = $logMessage + " ExceptionMessage: " + $exceptionMessage
        }
    }

    if ($LogMode -eq 0)
    {
        Try
        {
            WriteLogToConsole $logLevel $logMessage
        }
        Catch
        {
            # Error when logging to console
            $exceptionDetails = "Exception: " + $_.Exception.Message + "HResult: " + $_.Exception.HResult
            $message = "Error when logging to consloe."
            Write-Error "$message`n$exceptionDetails"
            SendEventToAppInsights "logging" $message "Failure" $global:utcDate "2" $_.Exception.HResult $_.Exception.Message
            [System.Environment]::Exit(2)
        }
    }
    elseif ($LogMode -eq 1)
    {
        Try
        {
            WriteLogToConsole $logLevel $logMessage
            Add-Content $global:logFile "$global:logDate : $logLevel : $logMessage"
        }
        Catch
        {
            # Error when logging to console and file
            $exceptionDetails = "Exception: " + $_.Exception.Message + "HResult: " + $_.Exception.HResult
            $message = "Error when logging to consloe and file."
            Write-Error "$message`n$exceptionDetails"
            SendEventToAppInsights "logging" $message "Failure" $global:utcDate "3" $_.Exception.HResult $_.Exception.Message
            [System.Environment]::Exit(3)
        }
    }
    elseif ($LogMode -eq 2)
    {
        Try
        {
            Add-Content $global:logFile "$global:logDate : $logLevel : $logMessage"
        }
        Catch
        {
            # Error when logging to file
            $exceptionDetails = "Exception: " + $_.Exception.Message + "HResult: " + $_.Exception.HResult
            $message = "Error when logging to file."
            Write-Error "$message`n$exceptionDetails"
            SendEventToAppInsights "logging" $message "Failure" $global:utcDate "4" $_.Exception.HResult $_.Exception.Message
            [System.Environment]::Exit(4)
        }
    }
    else
    {
        Try
        {
            WriteLogToConsole $logLevel $logMessage
            Add-Content $global:logFile "$global:logDate : $logLevel : $logMessage"
        }
        Catch
        {
            # Error when logging to console and file
            $exceptionDetails = "Exception: " + $_.Exception.Message + "HResult: " + $_.Exception.HResult
            $message = "Error when logging to consloe and file."
            Write-Error "$message`n$exceptionDetails"
            SendEventToAppInsights "logging" $message "Failure" $global:utcDate "5" $_.Exception.HResult $_.Exception.Message
            [System.Environment]::Exit(5)
        }
    }
}

function WriteLogToConsole($logLevel, $logMessage)
{
    switch ($logLevel)
    {
        "Error"   
            {    
                Write-Error "$global:logDate : $logMessage"; Break
            }
        "Exception"    
            {    
                Write-Error "$global:logDate : $logMessage"; Break
            }
        "Warning"    
            {    
                Write-Warning "$global:logDate : $logMessage"; Break
            }
        default     
            {    
                Write-Host "$global:logDate : $logMessage"; Break
            }
    }
}

# Calling the main function
&$main

# SIG # Begin signature block
# MIIjnwYJKoZIhvcNAQcCoIIjkDCCI4wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB35ktNHB3fC94L
# kLzaFjsmTc/79SzUG2QanfCwef3Ko6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdDCCFXACAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg0HXPjCbJ
# KazBJIG8ur/EJzR6Fmij6NedYO0N1KzXFqwwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQAwtMVhMqEwiTfEz/3DxVtalLJDjFkJEz7ndIv3wcO+
# cxWbxdg1T311DW8ExIwI62gjmhyyNh+a7XnRqbSTasfcrTGGTcpSz74pHZxVKN5h
# nrnaIqUjGvd2Qw0qdQvHHSisVAtTVPcRnAMCpdvVHl0+LbLIp04SQLtC3hhjKNsx
# DiZ/3OckWo7xCfR30vI8SHpzN7Y4+Cn2gPTTp7vNyMwZycg0Z+vYKo7zstA+BG7u
# T/O4VQxUc/Z4Gyc315y3O0AO+XUYX7MCf8IWcNZY8ntjZchwBmEP2xKISSmQQv1o
# TXaEcf/34DWjL1Pvot3JMrgmAlTA4IdQUx1g4ksMvEJzoYIS/jCCEvoGCisGAQQB
# gjcDAwExghLqMIIS5gYJKoZIhvcNAQcCoIIS1zCCEtMCAQMxDzANBglghkgBZQME
# AgEFADCCAVkGCyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIOdrb74jMFBbUTa23zVhYilkxKWSayTi7llOuFl1
# NZoIAgZgxVR0aJwYEzIwMjEwNzI0MjA1NTA2LjE2OVowBIACAfSggdikgdUwgdIx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046RkM0MS00QkQ0LUQyMjAxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2Wggg5NMIIE+TCCA+GgAwIBAgITMwAAAUAjGdZe3pUk
# MQAAAAABQDANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMDAeFw0yMDEwMTUxNzI4MjZaFw0yMjAxMTIxNzI4MjZaMIHSMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOkZDNDEtNEJENC1EMjIwMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArn1rM3Hq
# 1S9N0z8R+YKqZu25ykk5OlT8TsuwtdBWyDCRFoASk9fB6siColFhXBhyej4c3yIw
# N0UyJWBOTAjHteOIYjfCpx539rbgBI5/BTHtC+qcBT7ftPknTtQn89lNOcpP70fu
# YVZLoQsDnLjGxxtW/eVewR5Q0I1mWQfJy5xOfelk5OWjz3YV4HKtqyIRzJZd/Rzc
# Y8w6qmzoSNsYIdvliT2eeQZbyYTdJQsRozIKTMLCJUBfVjow2fJMDtzDB9XEOdfh
# PWzvUOadYgqqh0lslAR7NV90FFmZgZWARrG8j7ZnVnC5MOXOS/NI58S48ycsug0p
# N2NGLLk2YWjxCwIDAQABo4IBGzCCARcwHQYDVR0OBBYEFDVDHC4md0YgjozSqnVs
# +OeELQ5nMB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRP
# ME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEww
# SgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMv
# TWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0l
# BAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAGMMUq2gQuCC9wr4YhIS
# fPyobaNYV3Ov4YwWsSfIz/j1xaN9TvLAB2BxPi2CtRbgbBUf48n07yReZInwu2r8
# vwLoNG2TtYzey01DRyjjsNoiHF9UuRLFyKZChkKC3o9r0Oy2x0YYjUpDxVChZ5q5
# cAfw884wP0iUcYnKKGn8eJ0nwpr7zr/Tlu+HOjXDT9C754aS4KUFNm8D7iwuvWWz
# SOVl7XMWdu82BnnTmB7s2Ocf3I4adGzdixQ5Zxxa3zOAvKzrV+0HcVQIY3SQJ9Pz
# jDRlzCviMThxA8FUIRL3FnYqvchWkEoZ4w8S7FsGWNlXLWQ7fHMb3l4gjueHyO4p
# 6tUwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
# b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEy
# MTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwT
# l/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4J
# E458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhg
# RvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchoh
# iq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajy
# eioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwB
# BU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVj
# OlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsG
# A1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJc
# YmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9z
# b2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIz
# LmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0
# MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYx
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0
# bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMA
# dABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCY
# P4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1r
# VFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3
# fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2
# /QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFj
# nXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjgg
# tSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7
# cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwms
# ObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAv
# VCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGv
# WbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA1
# 2u8JJxzVs341Hgi62jbb01+P3nSISRKhggLXMIICQAIBATCCAQChgdikgdUwgdIx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046RkM0MS00QkQ0LUQyMjAxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAEKl5h7yE6Y7MpfmMpEb
# QzkJclFToIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJ
# KoZIhvcNAQEFBQACBQDkpof1MCIYDzIwMjEwNzI0MjAzNzA5WhgPMjAyMTA3MjUy
# MDM3MDlaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOSmh/UCAQAwCgIBAAICImUC
# Af8wBwIBAAICETMwCgIFAOSn2XUCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYB
# BAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOB
# gQCjtCiXahKLj2fnZwsA/cRwSlMfhenusJsJkiIfqWiLcj2WOiYtyCvfRNYTKrTa
# 6ok4KYJ/acISDESrV5+Ys6/de1FrOE21+mmKSCwXcNscZSKfDcyhis7cBIYRSMoH
# rEuIrzqhaMGLgpKfvjMzrdyFbkdjJGP33gEOcVXOUkQmyTGCAw0wggMJAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABQCMZ1l7elSQxAAAA
# AAFAMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEIIPvLd6DuS9S7VZxRU4lb2ot7YCpLxKfSeSSZTLE
# eutxMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgLzawterM0qRcJO/zcvJT
# 7do/ycp8RZsRSTqqtgIIl4MwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAUAjGdZe3pUkMQAAAAABQDAiBCAgvM24k17CBsf7hPYCCl3D
# aFlUxtIcZXp/TaZImNHAcTANBgkqhkiG9w0BAQsFAASCAQB3NYEJPX2mbPzhf+Wd
# 6vx0wKq59TFGgV6Rwaf5I46TXx4xxgmfydv8pmAHm21LuNewCTgn454UgxE4Gore
# WoXdG/PKIMyuw26EP373psml3aBi7g5ZW2+94fAan9hzHmD9D5XNO0OWclMXuLMt
# WJqVhDGsUldlKEfgjVhVqU6OAcGk1LC19a50asb1cpMqvsOsAmTk27jtSsaD7Lmh
# fNqwFU91xRLqujtHNtPXCypSK/9FmWQW3kecQXakmotKPiCui9x3V8CD5I31AYBC
# z6/FuY2MD4xtZZAZQerPHHNhzPfXX/cv/Ixp/6jg2Unt+POI0AP3wrr8VSNMRaKY
# Gm2m
# SIG # End signature block
